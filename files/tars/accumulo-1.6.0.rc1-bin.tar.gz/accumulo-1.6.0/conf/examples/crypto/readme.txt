This accumulo-site.xml file demonstrates how to configure the basic encryption at rest feature.  

The default configuration shown here is not entirely secure, as the master key for all encryption keys
is stored alongside the encrypted files.  Placing that master key somewhere secure is an exercise
left to the reader.
